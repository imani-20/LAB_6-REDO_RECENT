package com.example.lab_6_redo_recent;

import android.os.Bundle;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.lifecycle.ViewModelProvider;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.example.lab_6_redo_recent.databinding.ActivityChatRoomBinding;
import com.example.lab_6_redo_recent.databinding.SentMessageBinding;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;


public class ChatRoom extends AppCompatActivity {

    /*Declaring the ArrayList variable*/
    ArrayList<ChatMessages> messages;

    /*Declaring myAdapter*/
    private RecyclerView.Adapter<MyRowHolder> myAdapter;

    /* Declaring the variables */
    private ActivityChatRoomBinding binding;

    /*Declaring the chatRoom variable*/
    ChatRoomViewModel chatModel;

    /*The inner class added*/
    class MyRowHolder extends RecyclerView.ViewHolder {

        /*The variables for the sent_message xml*/
        TextView messageText;
        /*The variables are of type textView */
        TextView timeText;

        public MyRowHolder(@NonNull View itemView) { /* The constructor declared with the itemView as a parameter*/
            super(itemView); /* the superclass */
            messageText = itemView.findViewById(R.id.message); /* using the findView method to look for the TextView with the id messageText*/
            timeText = itemView.findViewById(R.id.time); /* same logic as the previous line */
        }
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        /* Initializing the chatModel */
        /*Declaring the ViewModel variable*/
        chatModel = new ViewModelProvider(this).get(ChatRoomViewModel.class);
        messages = chatModel.messages.getValue();


        /* Assigning the messages variable to get the Value */

        /* The if condition to verify the messages have never been set the 1st time you enter ChatRoom */
        if (messages == null) {
            chatModel.messages.postValue(messages = new ArrayList<>());
        }

        /* Instructing the binding and making the Act. variable to convert from XML to JAVA */
        binding = ActivityChatRoomBinding.inflate(getLayoutInflater());

        /* The send button */
        binding.sendButton.setOnClickListener(click -> {
            messages.add(new ChatMessages(binding.editTextTextPassword.getText().toString(), "", false));
            /* Notifying my adapter about the updates after declaring it */
            myAdapter.notifyItemInserted(messages.size() - 1);
            /* To clear the previous text */
            binding.editTextTextPassword.setText("");
        });

        /* The root is of the inflated layout */
        View view = binding.getRoot();
        setContentView(view);

        /* THE END OF TRANSFORMING THE CONTENT VIEW TO VIEW-BINDING
         *
         *
         * SETTING THE ADAPTER VARIABLE: THE ADAPTER BEING THE MIDDLE MAN BETWEEN THE VARIABLE AND THE DATA
         *
         * */

        /* Adding the Layout Manager code */
        binding.recyclerView.setLayoutManager(new LinearLayoutManager(this));

        /* The line of code below will initialize the 'recyclerView.setAdapter(myAdapter)' class */
        binding.recyclerView.setAdapter(myAdapter = new RecyclerView.Adapter<MyRowHolder>() {

            /* Imported methods */
            @NonNull
            @Override

            /* The onCreateViewHolder is meant to implement the layout */
            public MyRowHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
                /* The first line is assigning the binding variable with the task to convert the XML elements to Java objects
                 * The second line is to return the 1st XML layout: the root.
                 */
                SentMessageBinding binding = SentMessageBinding.inflate(getLayoutInflater());
                return new MyRowHolder(binding.getRoot());
                /* The Adapter Functions
                 * These codes are responsible for creating the ViewHolder object, therefore it represents the list
                 * View itemView = LayoutInflater.from(parent.getContext()).inflate(R.layout.sent_message, parent, false);
                 * return new MyRowHolder(itemView);
                 */
            }

            @Override
            /* Set the data for the ViewHolder project */
            public void onBindViewHolder(@NonNull MyRowHolder holder, int position) {
                holder.messageText.setText("");
                holder.timeText.setText("");
                /* The object that will be in the row */
                ChatMessages chatMessages = messages.get(position);
                /* The messageText in the onBindViewHolder folder */
                holder.messageText.setText(chatMessages.getMessage());
            }

            @Override
            public int getItemCount() {
                return messages.size();
            }

            /* The declaration of the method getItemViewType
             * The getItemViewType method starts HERE
             */
            @Override
            public int getItemViewType(int position) {
                return position;
            }

            /* The end of imported methods */
        });

        /* The Binding method of the Receive button
         * This is declaring the variable
         */
        Button receiveButton = binding.receiveButton;
        Button sendButton = binding.sendButton;
        /* Adding a click listener that will respond to the user input...
         * The receiveButton being the UI element in the XML file, and the setOnClickListener is the method being used which needs to be defined
         */
        receiveButton.setOnClickListener(new View.OnClickListener() {

            /* This is where the Receive button will be defined and manipulated */
            @Override
            public void onClick(View v) {
                /* The onClick handler for the Receive button */
                SimpleDateFormat sdf = new SimpleDateFormat("EEEE, dd-MMM-yyyy hh-mm-ss a");
                String currentDateAndTime = sdf.format(new Date());

                // Creating a new ChatMessage for received message
                messages.add(new ChatMessages(binding.editTextTextPassword.getText().toString(), currentDateAndTime, false));
            }
        });

        /* The send button */
        binding.sendButton.setOnClickListener(click -> {
            /* The SimpleDateFormat will be able to get the current date and time */
            SimpleDateFormat sdf = new SimpleDateFormat("EEEE, dd-MMM-yyyy hh-mm-ss a");
            String currentDateAndTime = sdf.format(new Date());

            /* The new ChatMessage object will add it to the messages ArrayList */
            messages.add(new ChatMessage(binding.editTextTextPassword.getText().toString(), currentDateandTime, true));

            /* This line of code is a method that will be able to notify the adapter about the updates */
            myAdapter.notifyItemInserted(messages.size() - 1);

            /* This code will ensure that the previous text is cleared */
            binding.editTextTextPassword.setText("");
        });

    }
}
